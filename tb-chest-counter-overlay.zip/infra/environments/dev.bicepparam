using '../main.bicep'

param prefix = 'tb'
param suffix = 'dev'
param tags = {
  project: 'tb-chest-counter'
  environment: 'dev'
  owner: 'adam'
}

// Replace with your AAD Object ID (az ad signed-in-user show --query id -o tsv)
param deployerObjectId = '<YOUR_AAD_OBJECT_ID>'

param pgAdminUser = 'tbadmin'
// pgAdminPassword provided at deploy time via --parameters or prompt

param clans = [
  {
    id: 'for-main'
    name: 'FOR'
    kingdom: 225
    scanIntervalHours: 4
    scanOffsetMinutes: 0
  }
  {
    id: 'for-academy'
    name: 'FOR Academy'
    kingdom: 225
    scanIntervalHours: 4
    scanOffsetMinutes: 10
  }
]

param enablePublicAccess = true
